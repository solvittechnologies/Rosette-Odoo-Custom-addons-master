# Part of rental-vertical See LICENSE file for full copyright and licensing details.

from . import sale
from . import product
from . import product_pricelist_item
from . import res_company
