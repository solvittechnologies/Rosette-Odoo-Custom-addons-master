
Contributors
------------

Odoo Community Association (OCA)/Elego Software Solutions GmbH


