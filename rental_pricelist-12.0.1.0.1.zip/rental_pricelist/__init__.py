# Part of rental-vertical See LICENSE file for full copyright and licensing details.

from .hooks import set_multi_sales_price
from . import models
