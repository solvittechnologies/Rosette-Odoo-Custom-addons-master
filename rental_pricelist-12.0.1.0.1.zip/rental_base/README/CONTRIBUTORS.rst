
Contributors
------------

elego Software Solutions GmbH, Odoo Community Association (OCA)


