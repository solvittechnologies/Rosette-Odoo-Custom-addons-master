# Part of rental-vertical See LICENSE file for full copyright and licensing details.
from . import stock_common
