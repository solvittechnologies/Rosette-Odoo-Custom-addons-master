* Go to *Project > Search > Tasks* or *Project > Dashboard*.
* Click on the icon with a clock.
* You will see the tasks or projects in the new view.
