* Pedro M. Baeza <pedro.baeza@tecnativa.com>
* Carlos Dauden <carlos.dauden@tecnativa.com>
* Alexandre Moreau <alexandre.moreau@doscaal.fr>
* Dennis Sluijk <d.sluijk@onestein.nl>
* Nikul Chaudhary <nikulchaudhary2112@gmail.com>
* Eduardo Magdalena <emagdalena@c2i.es> (C2i Change 2 improve http://www.c2i.es)
