Define a new view displaying events in an interactive visualization chart.

The widget is based on the external library
http://visjs.org/timeline_examples.html
