## Module <hr_linkedin_recruitment>

#### 03.05.2019
#### Version 12.0.1.0.0
##### ADD 
- Initial Commit (linkedin api v2)
