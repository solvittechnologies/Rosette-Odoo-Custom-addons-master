This module allow to add analytic accounts on stock inventory line whether
using Inventory Adjustments or updating quantity on hand product wizard.
