* Jordi Ballester (EFICENT) <jordi.ballester@eficent.com>.
* Enric Tobella <etobella@creublanca.es>
* Atte Isopuro <atte.isopuro@avoin.systems>
* Lois Rilo <lois.rilo@eficent.com>
* Raul Martin <raul.martin@braintec-group.com>
* Serpent Consulting Services Pvt. Ltd. <support@serpentcs.com>
* `Open Source Integrators <https://www.opensourceintegrators.com>`_

  * Maxime Chambreuil <mchambreuil@opensourceintegrators.com>
  * Steve Campbell <scampbell@opensourceintegrators.com>
