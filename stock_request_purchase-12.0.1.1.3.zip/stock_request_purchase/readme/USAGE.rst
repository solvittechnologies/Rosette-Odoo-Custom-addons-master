In case that the confirmation of the Stock Request results in an immediate
Purchase Order, the user will be able to display the PO's from the Stock
Request form view.
