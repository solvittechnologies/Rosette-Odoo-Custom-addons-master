* When a Stock Request is cancelled, it does not cancel the quantity included
  in the Purchase Order.
