This module allows for users to be able to display purchase orders that have
been created as a consequence of Stock Requests.
