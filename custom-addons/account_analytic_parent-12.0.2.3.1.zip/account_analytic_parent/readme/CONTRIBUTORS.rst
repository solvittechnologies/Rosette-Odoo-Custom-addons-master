* Eficent <http://www.eficent.com>
* Luxim d.o.o. <http://www.luxim.si>
* Matmoz d.o.o. <http://www.matmoz.si>
* Deneroteam. <dhaval@deneroteam.com>
* SerpentCS <http://www.serpentcs.com/>
* Pedro M. Baeza <pedro.baeza@tecnativa.com>
* Vicent Cubells <vicent.cubells@tecnativa.com>
* David Vidal <david.vidal@tecnativa.com>
* Jaume Planas <jaume.planas@minorisa.net>
* `CorporateHub <https://corporatehub.eu/>`__

  * Alexey Pelykh <alexey.pelykh@corphub.eu>
