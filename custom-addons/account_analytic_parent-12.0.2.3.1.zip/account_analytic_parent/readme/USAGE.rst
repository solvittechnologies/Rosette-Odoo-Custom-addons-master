Activate the analytic accounting in Accounting > Configuration > Settings
