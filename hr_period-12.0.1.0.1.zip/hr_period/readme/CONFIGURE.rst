Create a fiscal year
~~~~~~~~~~~~~~~~~~~~
Go to: Human Resources -> Configuration -> Payroll -> Payroll Fiscal Year

 - Select a type of schedule, e.g. monthly
 - Select a duration, e.g. from 2015-01-01 to 2015-12-31
 - Select when the payment is done, e.g. the second day of the next period
 - Click on create periods, then confirm

The first period of the year is now open and ready to be used.

Some companies have employees paid at different types of schedule.
In that case, you need to create as many fiscal years as types of schedule
required. The same applies in a multi-company configuration.
