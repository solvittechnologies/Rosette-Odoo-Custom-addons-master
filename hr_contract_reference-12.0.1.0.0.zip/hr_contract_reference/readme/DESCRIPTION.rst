This module was written to extend the functionality of employees contracts
to support sequence of contract reference which will be generated
automatically from the sequence predefined.