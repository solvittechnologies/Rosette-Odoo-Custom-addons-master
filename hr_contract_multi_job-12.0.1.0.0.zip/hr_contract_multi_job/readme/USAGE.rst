On every employee contract you can set multiple jobs, and mark one of the job
as the main job (the main job will be written afterwards in the job_id field).

.. image:: https://odoo-community.org/website/image/ir.attachment/5784_f2813bd/datas
   :alt: Try me on Runbot
   :target: https://runbot.odoo-community.org/runbot/116/12.0
