* David Dufresne <david.dufresne@savoirfairelinux.com>
* Pierre Lamarche <pierre.lamarche@savoirfairelinux.com>
* Fekete Mihai <feketemihai@gmail.com>
* Serpent Consulting Services Pvt. Ltd. <support@serpentcs.com>
