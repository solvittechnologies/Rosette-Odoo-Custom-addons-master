To install this module, you need to:

* clone the branch 12.0 of the repository https://github.com/OCA/hr
* add the path to this repository in your configuration (addons-path)
* update the module list
* search for "HR Contract Multi Jobs" in your addons
* install the module
