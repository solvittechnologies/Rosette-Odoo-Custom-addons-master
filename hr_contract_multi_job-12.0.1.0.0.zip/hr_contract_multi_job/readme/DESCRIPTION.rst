This module was written to extend the functionality of employees contracts
to support multiple jobs of the employee assigned on the same contract.

An example is a construction worker who makes different types of jobs
for the same company like bricklaying, electricity, carpentry.

Also in restaurants, a waiter can also work as a barman.
