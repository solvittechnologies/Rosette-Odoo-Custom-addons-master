# -*- coding: utf-8 -*-
from . import compare_payroll_rule_report
from . import compare_payslip_employee_report
