# -*- coding: utf-8 -*-
from . import compare_payroll_rule_wiz
from . import compare_payslip_employee_wiz
