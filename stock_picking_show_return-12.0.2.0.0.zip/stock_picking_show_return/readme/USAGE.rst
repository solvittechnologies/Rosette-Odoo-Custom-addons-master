To display returned pickings from this one
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

#. Go to any picking that has a return
#. See the new tab "Returns" appears.

To display origin picking from any returned picking
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

#. Go to any returned picking
#. See the new smart button "Origin picking" appears.
#. Click on button to open origin picking.
