# -*- coding: utf-8 -*-
# (C) 2018 Smile (<http://www.smile.fr>)
# License AGPL-3.0 or later (https://www.gnu.org/licenses/agpl).

{
    "name": "filtered_from_domain",
    "version": "0.1",
    "depends": ["base"],
    "author": "Smile",
    "license": 'AGPL-3',
    "description": """""",
    "website": "",
    'category': 'Tools',
    "sequence": 0,
    "data": [],
    "auto_install": True,
    "installable": True,
    "application": False,
}
