* In wizard, when `exclude_reserved` is selected, handle partially available moves.
* Use sequence numbering for procurement groups made from pull list.
* Return a pull list summary at the end.
