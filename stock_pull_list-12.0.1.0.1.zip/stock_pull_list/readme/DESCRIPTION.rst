The pull list checks the stock situation at the given location and calculates
the shortfall quantities (quantity needed to cover all needs) for products.
Procurements can be created for these shortfall quantities.
