To use the module follow the next steps:

#. Go to *Inventory > Operations > Generate Pull List*.
#. Select the location to get the pull list from. Add some filtering if needed.
#. Click on Prepare. You will now see the pull list with all the needs.
#. Adjust grouping options as needed. This will generate different procurement
   groups.
#. Click on *Procure*.
