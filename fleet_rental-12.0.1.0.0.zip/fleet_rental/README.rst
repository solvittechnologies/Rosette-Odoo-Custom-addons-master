Fleet Rental Management v12
===========================
This module will helps you to give the vehicles for Rent.

Features
========

* Multiple Plans for Rental Contract(Days/Weeks/Months/Years).
* Integrated with Accounting Module.
* Automatically Create Recurring Invoices.
* Sending email for confirmation, first payment and recurrent invoices.
* Check List Facility.
* Separate Tree view for Checklist.
* Damage Checking Facility.
* Billing Facility for Damages/Check Lists.
* Contract Payment Validations.
* Detailed Fleet Rental Analysis Report.
* Access Rights From Multiple Level.
Tech
====
* [Python] - Models
* [XML] - Odoo views

Installation
============
- www.odoo.com/documentation/12.0/setup/install.html
- Install our custom addon

Bug Tracker
===========
Bugs are tracked on GitHub Issues. In case of trouble, please check there if your issue has already been reported.


Developer: Avinash NK @ cybrosys, odoo@cybrosys.com

Maintainer
----------

This module is maintained by Cybrosys Technologies.

For support and more information, please visit https://www.cybrosys.com.
