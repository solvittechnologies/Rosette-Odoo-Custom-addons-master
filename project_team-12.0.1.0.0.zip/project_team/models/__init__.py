# See LICENSE file for full copyright and licensing details.

from . import project_team
from . import crm_team
