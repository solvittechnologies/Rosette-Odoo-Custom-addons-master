
=> 12.0.0.2 : Improved an index as per odoo12 version.

=> 12.0.0.3 : Make a new video for this module.
