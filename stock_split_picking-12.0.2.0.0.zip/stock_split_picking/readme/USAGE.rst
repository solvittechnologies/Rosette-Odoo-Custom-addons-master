#. Go to **Inventory** dashboard and open any picking.
#. If picking state is **available** you can see an split button.
#. On the "Operations" tab, fill the field "Done" to the quantity you want to
   split for each line.
#. If you click on **Split** button, wizard will split current picking into
   two different pickings depends on quantity done you entered above.
#. Both pickings remain confirmed.
