* Nicolas Bessi <nicolas.bessi@camptocamp.com>
* Guewen Baconnier <guewen.baconnier@camptocamp.com>
* Yannick Vaucher <yannick.vaucher@camptocamp.com>
* Vicent Cubells <vicent.cubells@tecnativa.com>
* Julien Coux <julien.coux@camptocamp.com>
* Andrius Preimantas <andrius@versada.eu>
* Holger Brunn <mail@hunki-enterprises.com>
