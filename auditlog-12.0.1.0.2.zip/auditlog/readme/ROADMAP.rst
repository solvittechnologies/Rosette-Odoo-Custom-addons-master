* Log only operations triggered by some users. Currently it logs all users.
* Logging read operations does not work on all data models. Need investigation.
