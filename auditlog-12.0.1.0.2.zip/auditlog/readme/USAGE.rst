Check logs in the `Settings / Technical / Audit / Logs` menu. You can
group them by user sessions, date, data model or HTTP requests:

.. image:: ../static/description/logs.png

Get the details:

.. image:: ../static/description/log.png
