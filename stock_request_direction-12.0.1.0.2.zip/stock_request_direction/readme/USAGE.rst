Creation
~~~~~~~~

* Go to Stock Requests > Stock Requests
* Create or select a stock request
* Provide a product, quantity, direction and expected date
* Click Confirm

Upon confirmation, the request will be reviewed by the warehouse team who can
define the appropriate route.

In case that transfers are created, the user will be able to access to them
from the button 'Transfers' available in the Stock Request.

Cancel
~~~~~~

When the user cancels a Stock Request, the related pending stock moves will be
also cancelled.
