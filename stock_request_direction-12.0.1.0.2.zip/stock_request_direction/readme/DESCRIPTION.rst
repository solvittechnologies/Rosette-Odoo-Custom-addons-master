This module was written to allow users to request products to be transferred
from or to your warehouses. They can specify the direction and don't have to
bother selecting the inventory location.
