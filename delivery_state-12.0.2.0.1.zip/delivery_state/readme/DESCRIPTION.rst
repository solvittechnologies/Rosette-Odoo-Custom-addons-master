This module adds additional functions that will be needed for the carrier
developments. It provides fields to be able to contemplate the tracking states
and also adds a global field so it can have generic states in addition to the
ones carrier gives us.
