* `Trey <https://www.trey.es>`_:

  * Roberto Lizana <roberto@trey.es>

* `FactorLibre <https://www.factorlibre.com>`_:

  * Zahra Velasco <zahra.velasco@factorlibre.com>
* `Tecnativa <https://www.tecnativa.com>`_:

  * Pedro M. Baeza
  * David Vidal
